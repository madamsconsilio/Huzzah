﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Default.aspx.cs" Inherits="Huzzah.Default" Async="true" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Huzzah Privilege Analysis</title>
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; margin: 20px; }
        .form-group { margin-bottom: 16px; }
        .form-group label { display: block; font-weight: bold; margin-bottom: 6px; }
        .form-control { width: 500px; padding: 6px 10px; font-size: 14px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; }
        .btn-primary { background-color: #0071e3; color: white; padding: 8px 18px; border: none; font-size: 14px; border-radius: 6px; cursor: pointer; }
        .btn-primary:hover { background-color: #0077ed; }
        .output-box { margin-top: 20px; padding: 12px; border: 1px solid #d2d2d7; background-color: #f5f5f7; width: 650px; white-space: pre-wrap; font-family: Menlo, Monaco, Consolas, monospace; font-size: 13px; border-radius: 6px; }
    </style>
</head>
<body>
    <form id="form1" runat="server">
        <h2>Huzzah - Document Privilege Analysis</h2>
        
        <div class="form-group">
            <asp:Label ID="DisplayLabel" runat="server" ForeColor="#0071e3" Font-Bold="true"></asp:Label>
        </div>

        <div class="form-group">
            <label for="ddlDynamicOptions">1. Select Folder:</label>
            <asp:DropDownList ID="ddlDynamicOptions" runat="server" CssClass="form-control"></asp:DropDownList>
        </div>

        <div class="form-group">
            <label for="ddlFields">2. Select Target PRIV Field:</label>
            <asp:DropDownList ID="ddlFields" runat="server" CssClass="form-control"></asp:DropDownList>
        </div>

        <div class="form-group">
            <label for="txtUserPrompt">3. Instructions / Prompt for Claude:</label>
            <asp:TextBox ID="txtUserPrompt" runat="server" TextMode="MultiLine" Rows="4" CssClass="form-control" 
                Text="Analyze the document text and determine if it contains privileged legal communications (Attorney-Client or Work-Product). State your reasoning and confidence level."></asp:TextBox>
        </div>

        <div class="form-group">
            <asp:Button ID="btnRunClaude" runat="server" Text="Execute Claude Analysis" CssClass="btn-primary" OnClick="btnRunClaude_Click" />
        </div>

        <div class="form-group">
            <label>Output Status:</label>
            <asp:Label ID="lblStatus" runat="server" Font-Bold="true"></asp:Label>
            <div id="divOutput" runat="server" class="output-box" visible="false">
                <asp:Literal ID="litClaudeResponse" runat="server"></asp:Literal>
            </div>
        </div>
    </form>
</body>
</html>
